import Head from "next/head";
import Image from "next/image";
import useMediaQuery from "@/hooks/useMediaQuery";
import Header from "@/components/Header";
import FeatureBox from "@/components/FeatureBox";
import ProjectSummary from "@/components/ProjectSummary";
import SectionTextBox from "../SectionText";
import FramedBox from "../FramedBox";
import TwoColBox from "../TwoColBox";
import SideNav from "../SideNav";
import ResponsiveSection from "@/components/ResponsiveSection";
import styles from "@/styles/Projects.module.css";

export default function NeighbourlyProject() {
	const isMobile = useMediaQuery("(max-width: 840px)");

	return (
		<>
			<Head>
				<title>Jasmine Putri | Portfolio | Neighbourly</title>
				<meta name="description" content="Neighbourly Project Case Study" />
				<link rel="icon" href="/favicon.ico" />
			</Head>

			<div className={styles.page}>
				<Header />

				<main className="gridContainer">
					<ResponsiveSection
						desktopStyle={{
							gridColumn: "4 / span 10",
							marginTop: "3rem",
							marginBottom: "5rem",
						}}
						mobileVariant="stacked"
						id="overview"
					>
						<ProjectSummary
							title="Neighbourly"
							details={[
								{ label: "role", value: "UI/UX Designer, Front-end Developer" },
								{ label: "timeline", value: "January 2024 — May 2024" },
								{ label: "type", value: "Website / Web App / Mobile App" },
								{ label: "toolstack", value: "Figma, Next.js" },
								{ label: "program used", value: "Next.js, Azure" },
								{
									label: "link",
									value: (
										<a href="https://be-neighbourly.com" target="_blank">
											be-neighbourly.com
										</a>
									),
								},
							]}
						/>

						{/* SideNav Component */}
						<SideNav
							className={styles.floatingSideNav}
							sections={[
								{ name: "Overview", id: "overview" },
								{ name: "Commercial", id: "commercial" },
								{ name: "Features", id: "features" },
								{ name: "Design & Branding", id: "design" },
							]}
						/>
					</ResponsiveSection>

					{/* OVERVIEW SECTION */}
					<ResponsiveSection
						desktopStyle={{ gridColumn: "4 / span 10" }}
						mobileVariant="stacked"
						id="overview"
					>
						<SectionTextBox
							title="What is Neighbourly?"
							subtitle="Overview"
							variant="compact"
							customStyles={{ outer: { maxWidth: "1200px" } }}
						>
							<p>
								Neighbourly is a mobile marketplace app designed to connect
								individuals within their local communities by enabling them to
								advertise services they offer.
							</p>
							<p>
								In today’s fast-paced world, people often feel disconnected from
								their neighbours, making it difficult to find trusted local help
								or contribute their own expertise. Neighbourly bridges this gap
								by creating a space where people can connect meaningfully,
								exchange skills, and build a stronger, more connected and
								supportive community.
							</p>
						</SectionTextBox>
					</ResponsiveSection>

					<div style={{ gridColumn: "2 / span 14", marginTop: "4rem" }}>
						<Image
							src="/images/neighbourly/homepage.webp"
							alt="Neighbourly Hero"
							width={1920}
							height={1080}
							style={{ width: "100%", height: "auto" }}
						/>
					</div>

					{/* FEATURES SECTION */}
					<section
						id="features"
						style={{
							gridColumn: "1 / span 16", // This spans the entire grid width
							display: "grid", // Ensures it's part of the grid
							gridTemplateColumns: "repeat(16, 1fr)", // Defines the 16-column system
						}}
					>
						<ResponsiveSection
							desktopStyle={{
								gridColumn: "4 / span 10",
								marginTop: "8rem",
								marginBottom: "8rem",
							}}
							mobileVariant="stacked"
							id="features"
						>
							<FeatureBox
								title="Key Features"
								features={[
									{
										heading: "Local Service Listings",
										description:
											"Browse and offer services within your community, from home repairs to tutoring.",
									},
									{
										heading: "Learning & Workshops",
										description:
											"Join or host local classes to share or gain new skills.",
									},
									{
										heading: "Mentorship Opportunities",
										description:
											"Connect with mentors for career guidance and skill development.",
									},
								]}
							/>
						</ResponsiveSection>

						<ResponsiveSection
							desktopStyle={{ gridColumn: "2 / span 14" }}
							mobileVariant="stacked"
						>
							<FramedBox
								outerBg="var(--beige)"
								innerBg="var(--taupe)"
								innerRounded
								innerWidth="65%"
								innerHeight="70%"
								innerMarginTop="4rem"
							>
								<TwoColBox
									variant="leftWide"
									align="center"
									justify="center"
									customStyles={{
										outer: {
											maxWidth: "60vw",
											padding: "0 2rem",
											marginLeft: "1rem",
										},
									}}
									leftContent={
										<img
											src="/images/neighbourly/james-plunk-service.webp"
											style={{ width: "80%", maxWidth: "500px" }}
										/>
									}
									rightContent={
										<FeatureBox
											features={[
												{
													heading: "In-app Booking",
													description:
														"Book local classes directly in the app.",
												},
											]}
											backgroundColors={["transparent"]}
										/>
									}
								/>
								<TwoColBox
									variant="rightWide"
									align="center"
									justify="center"
									customStyles={{
										outer: {
											maxWidth: "60vw",
											padding: "0 2rem",
											marginLeft: "8rem",
										},
									}}
									leftContent={
										<FeatureBox
											features={[
												{
													heading: "User Reviews",
													description:
														"See trusted reviews from your community.",
												},
											]}
											backgroundColors={["transparent"]}
										/>
									}
									rightContent={
										<img
											src="/images/neighbourly/mentor-pottery.webp"
											style={{ width: "80%", maxWidth: "500px" }}
										/>
									}
								/>
							</FramedBox>
						</ResponsiveSection>

						<ResponsiveSection
							desktopStyle={{ gridColumn: "2 / span 14" }}
							mobileVariant="stacked"
						>
							<FramedBox
								outerBg="var(--beige)"
								innerBg="transparent"
								innerRounded
							>
								<div
									style={{
										display: "grid",
										gridTemplateColumns: "repeat(2, 1fr)",
										gap: "2rem",
									}}
								>
									<FeatureBox
										features={[{ heading: "Interactive Map" }]}
										backgroundColors={["transparent"]}
									/>
									<FeatureBox
										features={[{ heading: "Multi-language Support" }]}
										backgroundColors={["transparent"]}
									/>
									<video
										src="/images/neighbourly/interactive-map.webm"
										autoPlay
										loop
										muted
										playsInline
										style={{ width: "100%", borderRadius: "12px" }}
									/>
									<video
										src="/images/neighbourly/language-settings.webm"
										autoPlay
										loop
										muted
										playsInline
										style={{ width: "100%", borderRadius: "12px" }}
									/>
								</div>
							</FramedBox>
						</ResponsiveSection>

						<ResponsiveSection
							desktopStyle={{ gridColumn: "2 / span 14" }}
							mobileVariant="stacked"
						>
							<FramedBox
								outerBg="var(--beige)"
								innerBg="var(--taupe)"
								innerWidth="65%"
								innerHeight="72%"
								innerRounded
							>
								<FeatureBox
									features={[{ heading: "Personalized Recommendations" }]}
									backgroundColors={["transparent"]}
								/>
								<Image
									src="/images/neighbourly/quiz-2.webp"
									alt="Personalized Quiz"
									width={1920}
									height={1080}
									style={{ width: "100%", height: "auto" }}
								/>
							</FramedBox>
						</ResponsiveSection>
					</section>

					{/* DESIGN & BRANDING SECTION */}
					<ResponsiveSection
						desktopStyle={{ gridColumn: "2 / span 14", paddingTop: "8rem" }}
						mobileVariant="stacked"
						id="design"
					>
						<FramedBox
							outerBg="var(--grey)"
							innerBg="transparent"
							innerRounded
							innerWidth="80%"
						>
							<FeatureBox
								title="Design & Branding"
								features={[{ heading: "App Architecture" }]}
								customStyles={{ margin: "0", marginTop: "0", padding: "0" }}
							/>
							<Image
								src="/images/neighbourly/architecture.webp"
								alt="App Architecture"
								width={1920}
								height={1080}
								style={{ width: "80%", height: "auto" }}
							/>

							<FeatureBox
								features={[{ heading: "Colour System" }]}
								customStyles={{ margin: "0", marginTop: "10rem", padding: "0" }}
							/>
							<Image
								src="/images/neighbourly/colours.webp"
								alt="Colour System"
								width={1920}
								height={1080}
								style={{ width: "80%", height: "auto" }}
							/>

							<FeatureBox
								features={[{ heading: "Typefaces" }]}
								customStyles={{ margin: "0", marginTop: "10rem", padding: "0" }}
							/>
							<Image
								src="/images/neighbourly/typefaces.webp"
								alt="Typefaces"
								width={1920}
								height={1080}
								style={{ width: "100%", height: "auto" }}
							/>

							<FeatureBox
								features={[{ heading: "Logo & Wordmark" }]}
								customStyles={{ margin: "0", marginTop: "10rem", padding: "0" }}
							/>
							<Image
								src="/images/neighbourly/logo.webp"
								alt="Logo & Wordmark"
								width={1920}
								height={1080}
								style={{ width: "60%", height: "auto" }}
							/>

							<FeatureBox
								features={[{ heading: "Feedback Graphics" }]}
								customStyles={{ margin: "0", marginTop: "10rem", padding: "0" }}
							/>
							<Image
								src="/images/neighbourly/feedback-gnomes.webp"
								alt="Feedback Graphics"
								width={1920}
								height={1080}
								style={{ width: "100%", height: "auto" }}
							/>

							<FeatureBox
								features={[{ heading: "Brand Characters" }]}
								customStyles={{ margin: "0", marginTop: "10rem", padding: "0" }}
							/>
							<Image
								src="/images/neighbourly/gnomes.webp"
								alt="Brand Characters"
								width={1920}
								height={1080}
								style={{ width: "100%", height: "auto" }}
							/>
						</FramedBox>
					</ResponsiveSection>
				</main>

				<footer
					style={{ marginTop: "5rem", textAlign: "center", fontSize: "0.9rem" }}
				>
					Jasmine Putri
				</footer>
			</div>
		</>
	);
}
